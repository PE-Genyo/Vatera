<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <title>budget vatera</title>

    <nav class="navbar navbar-inverse", style="background-color: #68ff89; width: 70%">

        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="index.php", style="font-size: 18pt; color: orange; font-weight: bold">Budgetera</a>
        </div>

        <ul class="nav navbar-nav">
            <li><a href="hello.php", style="font-size: 14pt; color: black; font-weight: bold">Izék</a></li>
            <li><a href="", style="font-size: 14pt; color: black; font-weight: bold">Bigyók</a></li>
        </ul>

        <ul class="nav navbar-nav navbar-right">
            <li>
                <a href="regform.php", style="font-size: 14pt; color: blue; font-weight: bold"><span class="glyphicon glyphicon-user"></span> Regisztráció</a></li>
            <li><a href="", style="font-size: 14pt; color: blue; font-weight: bold"><span class="glyphicon glyphicon-log-in"></span> Belépés</a></li>
        </ul>
        </div>

    </nav>

</head>