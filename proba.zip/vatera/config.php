<?php
	define('DB_SERVER','localhost');
	define('DB_USERNAME','vatera');
	define('DB_PASSWORD','vatera123');
	define('DB_DATABASE','vatera');

	$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>
