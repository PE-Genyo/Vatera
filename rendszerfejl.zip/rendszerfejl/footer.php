<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
<style type="text/css">
.footer {
		  position: fixed;
		  background-color: #777;
		  padding: 10px;
		  text-align: center;
		  bottom: 0px;
		  width: 100%;
		  color: white;
		}
</style>
</head>
<body>
<div class="footer">Made by: Horváth Bence, Keményik Bence, Tóth Ferenc, Pásztor Martin</div>
</body>
</html>